package com.goldenstudio.goldentv.network;

import com.goldenstudio.goldentv.tileentity.TileEntityTV;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class MessagePlayVideo implements IMessage {

    private BlockPos pos;
    private String videoPath;
    private boolean play; // true = start, false = stop

    // required no-arg constructor
    public MessagePlayVideo() {
    }

    public MessagePlayVideo(BlockPos pos, String videoPath, boolean play) {
        this.pos = pos;
        this.videoPath = videoPath;
        this.play = play;
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeLong(pos.toLong());
        ByteBufUtils.writeUTF8String(buf, videoPath == null ? "" : videoPath);
        buf.writeBoolean(play);
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        pos = BlockPos.fromLong(buf.readLong());
        videoPath = ByteBufUtils.readUTF8String(buf);
        play = buf.readBoolean();
    }

    public static class Handler implements IMessageHandler<MessagePlayVideo, IMessage> {
        @Override
        public IMessage onMessage(MessagePlayVideo message, MessageContext ctx) {
            EntityPlayerMP player = ctx.getServerHandler().player;
            player.getServerWorld().addScheduledTask(() -> {
                World world = player.getServerWorld();
                // basic sanity check: only allow control if the player is reasonably close
                if (player.getDistanceSq(message.pos) > 64 * 64) {
                    return;
                }
                TileEntity te = world.getTileEntity(message.pos);
                if (te instanceof TileEntityTV) {
                    TileEntityTV tv = (TileEntityTV) te;
                    if (message.play) {
                        tv.startPlayback(message.videoPath);
                    } else {
                        tv.stopPlayback();
                    }
                }
            });
            return null;
        }
    }
}
