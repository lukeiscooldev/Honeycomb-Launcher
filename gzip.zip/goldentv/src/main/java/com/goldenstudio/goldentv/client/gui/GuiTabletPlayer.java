package com.goldenstudio.goldentv.client.gui;

import com.goldenstudio.goldentv.client.VideoPlayer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import java.io.File;
import java.io.IOException;

public class GuiTabletPlayer extends GuiScreen {

    // shared across opens so re-opening the tablet mid-video keeps playing
    private static VideoPlayer activePlayer;
    private static DynamicTexture activeTexture;
    private static ResourceLocation activeTextureLocation;
    private static String lastPath = "";

    private GuiTextField pathField;

    @Override
    public void initGui() {
        super.initGui();
        pathField = new GuiTextField(0, fontRenderer, width / 2 - 100, height - 50, 200, 20);
        pathField.setMaxStringLength(256);
        pathField.setText(lastPath);

        buttonList.add(new GuiButton(1, width / 2 - 100, height - 26, 95, 20, "Play"));
        buttonList.add(new GuiButton(2, width / 2 + 5, height - 26, 95, 20, "Stop"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 1) {
            String path = pathField.getText().trim();
            if (!path.isEmpty()) {
                startVideo(path);
            }
        } else if (button.id == 2) {
            stopVideo();
        }
    }

    private void startVideo(String path) {
        stopVideo();
        lastPath = path;
        File videoDir = new File(Minecraft.getMinecraft().mcDataDir, "goldentv/videos");
        File videoFile = new File(videoDir, path);

        activePlayer = new VideoPlayer(videoFile, 0);
        activePlayer.start();
        activeTexture = new DynamicTexture(VideoPlayer.WIDTH, VideoPlayer.HEIGHT);
        activeTextureLocation = Minecraft.getMinecraft().getTextureManager()
                .getDynamicTextureLocation("goldentv_tablet", activeTexture);
    }

    private void stopVideo() {
        if (activePlayer != null) {
            activePlayer.stop();
            activePlayer = null;
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        pathField.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1) {
            mc.displayGuiScreen(null);
            return;
        }
        pathField.textboxKeyTyped(typedChar, keyCode);
    }

    @Override
    public void updateScreen() {
        pathField.updateCursorCounter();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();

        if (activePlayer != null) {
            if (activePlayer.isFailed()) {
                drawCenteredString(fontRenderer, "Error: " + activePlayer.getFailReason(), width / 2, height / 2, 0xFF5555);
            } else {
                byte[] frame = activePlayer.pollNewFrame();
                if (frame != null) {
                    uploadFrame(frame);
                }
                drawScreenQuad();
            }
        } else {
            drawCenteredString(fontRenderer, "Golden Tablet - enter a video filename below", width / 2, height / 2 - 60, 0xFFD700);
        }

        pathField.drawTextBox();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void uploadFrame(byte[] rgba) {
        int[] pixels = activeTexture.getTextureData();
        int px = 0;
        for (int i = 0; i < VideoPlayer.WIDTH * VideoPlayer.HEIGHT; i++) {
            int r = rgba[px++] & 0xFF;
            int g = rgba[px++] & 0xFF;
            int b = rgba[px++] & 0xFF;
            int a = rgba[px++] & 0xFF;
            pixels[i] = (a << 24) | (r << 16) | (g << 8) | b;
        }
        activeTexture.updateDynamicTexture();
    }

    private void drawScreenQuad() {
        int vidW = 320, vidH = 180;
        int x = width / 2 - vidW / 2;
        int y = height / 2 - vidH / 2 - 20;

        mc.getTextureManager().bindTexture(activeTextureLocation);
        GlStateManager.color(1f, 1f, 1f, 1f);
        net.minecraft.client.renderer.Tessellator tess = net.minecraft.client.renderer.Tessellator.getInstance();
        net.minecraft.client.renderer.BufferBuilder buf = tess.getBuffer();
        buf.begin(7, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION_TEX);
        buf.pos(x, y + vidH, 0).tex(0, 1).endVertex();
        buf.pos(x + vidW, y + vidH, 0).tex(1, 1).endVertex();
        buf.pos(x + vidW, y, 0).tex(1, 0).endVertex();
        buf.pos(x, y, 0).tex(0, 0).endVertex();
        tess.draw();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
