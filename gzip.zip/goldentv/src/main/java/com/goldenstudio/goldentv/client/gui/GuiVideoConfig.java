package com.goldenstudio.goldentv.client.gui;

import com.goldenstudio.goldentv.network.MessagePlayVideo;
import com.goldenstudio.goldentv.network.PacketHandler;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.math.BlockPos;

import java.io.IOException;

public class GuiVideoConfig extends GuiScreen {

    private final BlockPos pos;
    private GuiTextField pathField;

    public GuiVideoConfig(BlockPos pos) {
        this.pos = pos;
    }

    @Override
    public void initGui() {
        super.initGui();
        int cx = width / 2;
        int cy = height / 2;

        pathField = new GuiTextField(0, fontRenderer, cx - 100, cy - 30, 200, 20);
        pathField.setMaxStringLength(256);
        pathField.setFocused(true);

        buttonList.add(new GuiButton(1, cx - 100, cy, 95, 20, "Play"));
        buttonList.add(new GuiButton(2, cx + 5, cy, 95, 20, "Stop"));
        buttonList.add(new GuiButton(3, cx - 100, cy + 26, 200, 20, "Cancel"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 1) {
            String path = pathField.getText().trim();
            if (!path.isEmpty()) {
                PacketHandler.NETWORK.sendToServer(new MessagePlayVideo(pos, path, true));
            }
            mc.displayGuiScreen(null);
        } else if (button.id == 2) {
            PacketHandler.NETWORK.sendToServer(new MessagePlayVideo(pos, "", false));
            mc.displayGuiScreen(null);
        } else if (button.id == 3) {
            mc.displayGuiScreen(null);
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1) { // ESC
            mc.displayGuiScreen(null);
            return;
        }
        if (keyCode == 28 || keyCode == 156) { // ENTER
            actionPerformed(buttonList.get(0));
            return;
        }
        pathField.textboxKeyTyped(typedChar, keyCode);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        pathField.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void updateScreen() {
        pathField.updateCursorCounter();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        int cx = width / 2;
        int cy = height / 2;
        drawCenteredString(fontRenderer, "Golden TV - video filename (in goldentv/videos/)", cx, cy - 50, 0xFFD700);
        pathField.drawTextBox();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
