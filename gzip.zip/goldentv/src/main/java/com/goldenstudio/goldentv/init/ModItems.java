package com.goldenstudio.goldentv.init;

import com.goldenstudio.goldentv.GoldenTV;
import com.goldenstudio.goldentv.items.ItemTablet;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = GoldenTV.MODID)
public class ModItems {

    public static final ItemTablet TABLET = new ItemTablet();

    public static void register() {
        // registry event below handles the actual forge registry insert
    }

    @SubscribeEvent
    public static void onRegisterItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().register(TABLET);
    }
}
