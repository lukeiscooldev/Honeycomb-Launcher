package com.goldenstudio.goldentv.init;

import com.goldenstudio.goldentv.GoldenTV;
import com.goldenstudio.goldentv.blocks.BlockTV;
import com.goldenstudio.goldentv.tileentity.TileEntityTV;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod.EventBusSubscriber(modid = GoldenTV.MODID)
public class ModBlocks {

    public static final BlockTV TV = new BlockTV();

    /** Called from CommonProxy#preInit. Registers the tile entity + subscribes registry events. */
    public static void register() {
        GameRegistry.registerTileEntity(TileEntityTV.class, new net.minecraft.util.ResourceLocation(GoldenTV.MODID, "tv"));
    }

    @SubscribeEvent
    public static void onRegisterBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().register(TV);
    }

    @SubscribeEvent
    public static void onRegisterItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().register(new ItemBlock(TV).setRegistryName(TV.getRegistryName()));
    }
}
