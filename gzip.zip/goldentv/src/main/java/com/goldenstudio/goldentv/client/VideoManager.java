package com.goldenstudio.goldentv.client;

import com.goldenstudio.goldentv.GoldenTV;
import com.goldenstudio.goldentv.tileentity.TileEntityTV;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@SideOnly(Side.CLIENT)
public class VideoManager {

    public static final VideoManager INSTANCE = new VideoManager();

    public static class Session {
        public VideoPlayer player;
        public DynamicTexture texture;
        public ResourceLocation textureLocation;
    }

    private final Map<TileEntityTV, Session> sessions = new HashMap<>();
    private final java.util.Set<TileEntityTV> reportedFailures = new java.util.HashSet<>();
    private int idCounter = 0;

    /** Call every render tick from the TESR (or GUI). Starts/refreshes/stops as needed. */
    public Session getOrCreate(TileEntityTV te, int width, int height) {
        Session session = sessions.get(te);

        if (!te.isPlaying()) {
            if (session != null) {
                session.player.stop();
                sessions.remove(te);
                reportedFailures.remove(te);
            }
            return null;
        }

        if (session == null) {
            session = new Session();
            File videoDir = new File(Minecraft.getMinecraft().mcDataDir, "goldentv/videos");
            File videoFile = new File(videoDir, te.getVideoPath());

            double elapsedSeconds = getElapsedSeconds(te);
            session.player = new VideoPlayer(videoFile, elapsedSeconds);
            session.player.start();

            session.texture = new DynamicTexture(width, height);
            session.textureLocation = Minecraft.getMinecraft().getTextureManager()
                    .getDynamicTextureLocation("goldentv_" + (idCounter++), session.texture);

            sessions.put(te, session);
        }

        // upload a new frame if the decoder has one ready
        byte[] frame = session.player.pollNewFrame();
        if (frame != null) {
            uploadFrame(session.texture, frame, width, height);
        }

        reportFailureOnce(te, session.player);

        return session;
    }

    /** Surfaces decode/audio failures to the player once each, instead of a silently black/muted TV. */
    private void reportFailureOnce(TileEntityTV te, VideoPlayer player) {
        if (reportedFailures.contains(te)) return;
        String message = null;
        if (player.isFailed()) {
            message = "Golden TV: " + player.getFailReason();
        } else if (player.isAudioFailed()) {
            message = "Golden TV (audio only): " + player.getAudioFailReason();
        }
        if (message != null) {
            reportedFailures.add(te);
            if (Minecraft.getMinecraft().player != null) {
                Minecraft.getMinecraft().player.sendStatusMessage(
                        new net.minecraft.util.text.TextComponentString(message), false);
            }
        }
    }

    private double getElapsedSeconds(TileEntityTV te) {
        net.minecraft.world.World world = Minecraft.getMinecraft().world;
        if (world == null) return 0;
        long elapsedTicks = world.getTotalWorldTime() - te.getStartWorldTime();
        return Math.max(0, elapsedTicks / 20.0);
    }

    private void uploadFrame(DynamicTexture texture, byte[] rgba, int width, int height) {
        int[] pixels = texture.getTextureData();
        int px = 0;
        for (int i = 0; i < width * height; i++) {
            int r = rgba[px++] & 0xFF;
            int g = rgba[px++] & 0xFF;
            int b = rgba[px++] & 0xFF;
            int a = rgba[px++] & 0xFF;
            pixels[i] = (a << 24) | (r << 16) | (g << 8) | b;
        }
        texture.updateDynamicTexture();
    }

    /** Call on world unload / mod cleanup to kill any stray ffmpeg processes. */
    public void stopAll() {
        for (Session s : sessions.values()) {
            s.player.stop();
        }
        sessions.clear();
        reportedFailures.clear();
    }

    public void stop(TileEntityTV te) {
        Session s = sessions.remove(te);
        reportedFailures.remove(te);
        if (s != null) {
            s.player.stop();
        }
    }
}
