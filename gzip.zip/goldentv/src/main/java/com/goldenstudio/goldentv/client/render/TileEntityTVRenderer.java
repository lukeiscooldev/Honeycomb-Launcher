package com.goldenstudio.goldentv.client.render;

import com.goldenstudio.goldentv.blocks.BlockTV;
import com.goldenstudio.goldentv.client.VideoManager;
import com.goldenstudio.goldentv.client.VideoPlayer;
import com.goldenstudio.goldentv.tileentity.TileEntityTV;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.EnumFacing;

public class TileEntityTVRenderer extends TileEntitySpecialRenderer<TileEntityTV> {

    // matches the screen element in goldentv_tv.json: x 1-15, y 3-12, z front face at 15/16
    private static final double SCREEN_HALF_WIDTH = 7.0 / 16.0;
    private static final double SCREEN_CENTER_Y = 7.5 / 16.0; // (3+12)/2 - 0.5, relative to block center
    private static final double SCREEN_HALF_HEIGHT = (9.0 / 2.0) / 16.0; // 16:9 slice, matches the model's uv height
    private static final double SCREEN_Z = 15.02 / 16.0 - 0.5; // just proud of the screen face, avoid z-fighting

    @Override
    public void render(TileEntityTV te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
        if (!te.isPlaying() || te.getWorld() == null) {
            return;
        }

        VideoManager.Session session = VideoManager.INSTANCE.getOrCreate(te, VideoPlayer.WIDTH, VideoPlayer.HEIGHT);
        if (session == null) {
            return;
        }

        IBlockState state = te.getWorld().getBlockState(te.getPos());
        EnumFacing facing = state.getBlock() instanceof BlockTV ? state.getValue(BlockTV.FACING) : EnumFacing.NORTH;

        GlStateManager.pushMatrix();
        GlStateManager.translate(x + 0.5, y + 0.5, z + 0.5);

        float rotY;
        switch (facing) {
            case SOUTH: rotY = 0f; break;
            case WEST:  rotY = 90f; break;
            case NORTH: rotY = 180f; break;
            case EAST:  rotY = -90f; break;
            default:    rotY = 0f; break;
        }
        GlStateManager.rotate(rotY, 0f, 1f, 0f);

        GlStateManager.disableLighting();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
        bindTexture(session.textureLocation);

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();
        buf.begin(7, DefaultVertexFormats.POSITION_TEX);
        buf.pos(-SCREEN_HALF_WIDTH, SCREEN_CENTER_Y + SCREEN_HALF_HEIGHT, SCREEN_Z).tex(1, 0).endVertex();
        buf.pos(SCREEN_HALF_WIDTH, SCREEN_CENTER_Y + SCREEN_HALF_HEIGHT, SCREEN_Z).tex(0, 0).endVertex();
        buf.pos(SCREEN_HALF_WIDTH, SCREEN_CENTER_Y - SCREEN_HALF_HEIGHT, SCREEN_Z).tex(0, 1).endVertex();
        buf.pos(-SCREEN_HALF_WIDTH, SCREEN_CENTER_Y - SCREEN_HALF_HEIGHT, SCREEN_Z).tex(1, 1).endVertex();
        tess.draw();

        GlStateManager.enableLighting();
        GlStateManager.popMatrix();
    }
}
