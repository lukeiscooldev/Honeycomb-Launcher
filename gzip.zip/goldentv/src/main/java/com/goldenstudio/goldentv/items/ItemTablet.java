package com.goldenstudio.goldentv.items;

import com.goldenstudio.goldentv.GoldenTV;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class ItemTablet extends Item {

    public ItemTablet() {
        setRegistryName("goldentv_tablet");
        setUnlocalizedName("goldentv_tablet");
        setMaxStackSize(1);
        setCreativeTab(net.minecraft.creativetab.CreativeTabs.TOOLS);
    }

    @Override
    public ActionResult<net.minecraft.item.ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
        if (worldIn.isRemote) {
            GoldenTV.proxy.openTabletGui();
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, playerIn.getHeldItem(handIn));
    }
}
