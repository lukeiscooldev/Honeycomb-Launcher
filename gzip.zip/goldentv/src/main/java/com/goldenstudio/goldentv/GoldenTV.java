package com.goldenstudio.goldentv;

import com.goldenstudio.goldentv.init.ModBlocks;
import com.goldenstudio.goldentv.init.ModItems;
import com.goldenstudio.goldentv.network.PacketHandler;
import com.goldenstudio.goldentv.proxy.CommonProxy;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

/**
 * Golden TV - lets players place a TV block (or hold a tablet) that plays an
 * mp4 file by shelling out to a local ffmpeg install and streaming decoded
 * frames onto an in-game texture.
 *
 * Requires ffmpeg to be installed and on PATH on the CLIENT machine that is
 * watching the video. Video files live in .minecraft/goldentv/videos/.
 */
@Mod(modid = GoldenTV.MODID, name = GoldenTV.NAME, version = GoldenTV.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class GoldenTV {

    public static final String MODID = "goldentv";
    public static final String NAME = "Golden TV";
    public static final String VERSION = "1.0.0";

    @SidedProxy(clientSide = "com.goldenstudio.goldentv.proxy.ClientProxy",
                serverSide = "com.goldenstudio.goldentv.proxy.CommonProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        PacketHandler.registerMessages();
        proxy.preInit();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init();
    }
}
