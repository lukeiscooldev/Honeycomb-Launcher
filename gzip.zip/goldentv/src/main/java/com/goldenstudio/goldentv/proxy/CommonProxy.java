package com.goldenstudio.goldentv.proxy;

import com.goldenstudio.goldentv.init.ModBlocks;
import com.goldenstudio.goldentv.init.ModItems;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class CommonProxy {

    public void preInit() {
        ModBlocks.register();
        ModItems.register();
    }

    public void init() {
        // no-op on dedicated server
    }

    /** Overridden client-side to pop open the video config screen. */
    public void openVideoConfigGui(BlockPos pos) {
        // no-op on dedicated server
    }

    /** Overridden client-side to pop open the tablet screen. */
    public void openTabletGui() {
        // no-op on dedicated server
    }
}
