package com.goldenstudio.goldentv.client;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Decodes an mp4 file to raw RGBA frames by shelling out to a locally
 * installed ffmpeg binary. No native Java video codec libs are bundled -
 * this keeps the mod jar tiny and avoids per-platform native binaries, at
 * the cost of requiring ffmpeg on PATH for whoever is watching.
 *
 * Usage: create one VideoPlayer per TileEntity/GUI instance, call start(),
 * then every render tick call getLatestFrame() and upload it to your
 * DynamicTexture if it has changed.
 */
@SideOnly(Side.CLIENT)
public class VideoPlayer {

    public static final int WIDTH = 480;
    public static final int HEIGHT = 270;
    public static final int FPS = 20;
    private static final long FRAME_INTERVAL_MS = 1000L / FPS;

    private final File videoFile;
    private final double startOffsetSeconds;

    private Process ffmpegProcess;
    private Thread decodeThread;
    private AudioStreamPlayer audioPlayer;

    private volatile byte[] latestFrame;
    private volatile boolean frameIsNew = false;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile boolean failed = false;
    private volatile String failReason = "";

    public VideoPlayer(File videoFile, double startOffsetSeconds) {
        this.videoFile = videoFile;
        this.startOffsetSeconds = Math.max(0, startOffsetSeconds);
    }

    public void start() {
        if (running.get()) return;
        if (!videoFile.exists()) {
            failed = true;
            failReason = "File not found: " + videoFile.getAbsolutePath();
            return;
        }
        running.set(true);

        decodeThread = new Thread(this::decodeLoop, "goldentv-decode");
        decodeThread.setDaemon(true);
        decodeThread.start();

        audioPlayer = new AudioStreamPlayer(videoFile, startOffsetSeconds);
        audioPlayer.start();
    }

    private void decodeLoop() {
        int frameSize = WIDTH * HEIGHT * 4; // RGBA
        try {
            ProcessBuilder pb = new ProcessBuilder(
                    "ffmpeg",
                    "-ss", String.valueOf(startOffsetSeconds),
                    "-i", videoFile.getAbsolutePath(),
                    "-f", "rawvideo",
                    "-pix_fmt", "rgba",
                    "-s", WIDTH + "x" + HEIGHT,
                    "-r", String.valueOf(FPS),
                    "-an",
                    "-loglevel", "error",
                    "pipe:1"
            );
            pb.redirectErrorStream(false);
            ffmpegProcess = pb.start();

            InputStream in = ffmpegProcess.getInputStream();
            byte[] buffer = new byte[frameSize];

            while (running.get()) {
                if (!readFully(in, buffer, frameSize)) {
                    break; // stream ended (video finished)
                }
                latestFrame = buffer.clone();
                frameIsNew = true;

                // pace ourselves roughly to FPS; DynamicTexture upload happens on render thread
                try {
                    Thread.sleep(FRAME_INTERVAL_MS);
                } catch (InterruptedException ignored) {
                    break;
                }
            }
        } catch (IOException e) {
            failed = true;
            failReason = "ffmpeg not found or failed to run. Is it installed and on PATH? (" + e.getMessage() + ")";
        } finally {
            running.set(false);
        }
    }

    private boolean readFully(InputStream in, byte[] buffer, int length) throws IOException {
        int total = 0;
        while (total < length) {
            int read = in.read(buffer, total, length - total);
            if (read < 0) return false;
            total += read;
        }
        return true;
    }

    /** Returns the latest decoded frame if it's changed since last call, else null. */
    public byte[] pollNewFrame() {
        if (frameIsNew) {
            frameIsNew = false;
            return latestFrame;
        }
        return null;
    }

    public boolean isFailed() {
        return failed;
    }

    public String getFailReason() {
        return failReason;
    }

    public boolean isRunning() {
        return running.get();
    }

    public void stop() {
        running.set(false);
        if (ffmpegProcess != null) {
            ffmpegProcess.destroy();
        }
        if (decodeThread != null) {
            decodeThread.interrupt();
        }
        if (audioPlayer != null) {
            audioPlayer.stop();
        }
    }
}
