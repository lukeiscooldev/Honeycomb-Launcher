package com.goldenstudio.goldentv.client;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * Plays the audio track of the video via ffmpeg -> raw PCM -> javax.sound.
 * This is a best-effort sync with the video frames (both are started at
 * roughly the same time); it is NOT sample-accurate lip sync.
 *
 * IMPORTANT: this previously failed 100% silently on error (a bare
 * catch (Exception e) {} swallowed everything). That's fixed now - any
 * failure is captured in failReason so the GUI/chat can actually tell you
 * what broke instead of just... not playing sound with zero explanation.
 *
 * The most common real-world cause of failure here is the JVM having no
 * usable audio mixer at all - this shows up a lot running Minecraft through
 * Wine-based Android launchers (Winlator etc), where javax.sound has to
 * route through Wine's audio emulation and that layer isn't always set up.
 * That's an environment problem, not something this code can patch around,
 * but at least now you'll see the real LineUnavailableException instead of
 * silence with no clue why.
 */
@SideOnly(Side.CLIENT)
public class AudioStreamPlayer {

    private static final int SAMPLE_RATE = 44100;
    private static final int CHANNELS = 2;

    private final File videoFile;
    private final double startOffsetSeconds;
    private Process ffmpegProcess;
    private Thread audioThread;
    private volatile boolean running = false;

    private volatile boolean failed = false;
    private volatile String failReason = "";

    public AudioStreamPlayer(File videoFile, double startOffsetSeconds) {
        this.videoFile = videoFile;
        this.startOffsetSeconds = startOffsetSeconds;
    }

    public void start() {
        running = true;
        audioThread = new Thread(this::run, "goldentv-audio");
        audioThread.setDaemon(true);
        audioThread.start();
    }

    private void run() {
        SourceDataLine line = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(
                    "ffmpeg",
                    "-ss", String.valueOf(startOffsetSeconds),
                    "-i", videoFile.getAbsolutePath(),
                    "-f", "s16le",
                    "-ar", String.valueOf(SAMPLE_RATE),
                    "-ac", String.valueOf(CHANNELS),
                    "-vn",
                    "-loglevel", "error",
                    "pipe:1"
            );
            ffmpegProcess = pb.start();
            InputStream in = ffmpegProcess.getInputStream();

            AudioFormat format = new AudioFormat(SAMPLE_RATE, 16, CHANNELS, true, false);

            try {
                line = AudioSystem.getSourceDataLine(format);
                line.open(format);
            } catch (LineUnavailableException e) {
                failed = true;
                failReason = "No usable audio output line available on this JVM/device "
                        + "(common on Wine-based Android launchers - the audio backend "
                        + "may not be configured). Video will still play. (" + e.getMessage() + ")";
                return;
            }

            line.start();

            byte[] buf = new byte[4096];
            int read;
            while (running && (read = in.read(buf)) != -1) {
                line.write(buf, 0, read);
            }
            line.drain();
        } catch (IOException e) {
            failed = true;
            failReason = "ffmpeg audio pipe failed to start: " + e.getMessage();
        } catch (Exception e) {
            failed = true;
            failReason = "Audio playback error: " + e.getClass().getSimpleName() + " - " + e.getMessage();
        } finally {
            if (line != null) {
                line.close();
            }
        }
    }

    public boolean isFailed() {
        return failed;
    }

    public String getFailReason() {
        return failReason;
    }

    public void stop() {
        running = false;
        if (ffmpegProcess != null) {
            ffmpegProcess.destroy();
        }
        if (audioThread != null) {
            audioThread.interrupt();
        }
    }
}
