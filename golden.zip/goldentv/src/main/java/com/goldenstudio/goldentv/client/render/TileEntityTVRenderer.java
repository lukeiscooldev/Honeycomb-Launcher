package com.goldenstudio.goldentv.client.render;

import com.goldenstudio.goldentv.client.VideoManager;
import com.goldenstudio.goldentv.client.VideoPlayer;
import com.goldenstudio.goldentv.tileentity.TileEntityTV;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.EnumFacing;

public class TileEntityTVRenderer extends TileEntitySpecialRenderer<TileEntityTV> {

    private static final double INSET = 0.502; // just proud of the block face, avoid z-fighting
    private static final double MARGIN = 0.08;  // screen margin inside the frame

    @Override
    public void render(TileEntityTV te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
        if (!te.isPlaying()) {
            return;
        }

        VideoManager.Session session = VideoManager.INSTANCE.getOrCreate(te, VideoPlayer.WIDTH, VideoPlayer.HEIGHT);
        if (session == null) {
            return;
        }

        GlStateManager.pushMatrix();
        GlStateManager.translate(x + 0.5, y + 0.5, z + 0.5);

        EnumFacing facing = te.getFacing();
        float rotY = 0f;
        switch (facing) {
            case NORTH: rotY = 180f; break;
            case SOUTH: rotY = 0f; break;
            case WEST:  rotY = 90f; break;
            case EAST:  rotY = -90f; break;
            default: break;
        }
        GlStateManager.rotate(rotY, 0f, 1f, 0f);

        GlStateManager.disableLighting();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1f, 1f, 1f, 1f);
        bindTexture(session.textureLocation);

        double half = 0.5 - MARGIN;

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();
        buf.begin(7, DefaultVertexFormats.POSITION_TEX);
        // quad sits on the +Z local face (which SOUTH points to before rotation)
        buf.pos(-half, half, INSET).tex(1, 0).endVertex();
        buf.pos(half, half, INSET).tex(0, 0).endVertex();
        buf.pos(half, -half, INSET).tex(0, 1).endVertex();
        buf.pos(-half, -half, INSET).tex(1, 1).endVertex();
        tess.draw();

        GlStateManager.enableLighting();
        GlStateManager.popMatrix();
    }
}
