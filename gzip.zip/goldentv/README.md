# Golden TV — MP4 playback for Minecraft Forge 1.12.2

Adds two ways to watch a video in-game:
- **Golden TV block** — place it, right click, type a filename, hit Play. Video plays on the
  block's face for anyone nearby, roughly in sync (late joiners seek to the current playback point).
- **Golden Tablet item** — handheld, personal, fullscreen video player. No sync needed since only you see it.

## How it actually plays video (important — read this)

Minecraft has zero built-in video codec support, and there's no clean way to add one without
either bundling huge native libraries (VLC) or a pure-Java decoder that struggles with real mp4s.
So this mod takes the pragmatic route: **it shells out to a local `ffmpeg` install** to decode
frames to raw RGBA and audio to raw PCM, then streams those into the game:

- `VideoPlayer.java` spawns `ffmpeg` and reads a continuous stream of raw video frames from stdout.
- `AudioStreamPlayer.java` spawns a second `ffmpeg` process for the audio track, played via `javax.sound`.
- `VideoManager.java` / `GuiTabletPlayer.java` upload each new frame into a `DynamicTexture` on the
  render thread, which the TESR (`TileEntityTVRenderer.java`) or GUI then draws as a textured quad.

**This means anyone who wants to WATCH a video needs ffmpeg installed and on PATH.** No ffmpeg = no
picture, and `VideoPlayer` will report a clear "ffmpeg not found" error in that case instead of crashing.
This does NOT need to be installed at build time — GitHub Actions doesn't need it, only players' machines do.

Video files go in `.minecraft/goldentv/videos/<filename>.mp4` on the client. Type just the filename
(e.g. `intro.mp4`) into the GUI text field.

## Project layout

```
build.gradle                     - ForgeGradle 1.12.2 build script
.github/workflows/build.yml      - CI build (matches your existing GH Actions flow)
src/main/java/com/goldenstudio/goldentv/
  GoldenTV.java                  - mod entry point
  proxy/                         - Common/Client sided proxy
  init/                          - block + item registration
  blocks/BlockTV.java
  items/ItemTablet.java
  tileentity/TileEntityTV.java   - playback state, synced to clients
  network/                       - client -> server "play/stop" packet
  client/VideoPlayer.java        - ffmpeg video decode
  client/AudioStreamPlayer.java  - ffmpeg audio decode
  client/VideoManager.java       - one decode session per playing TV
  client/render/TileEntityTVRenderer.java - draws the quad in-world
  client/gui/GuiVideoConfig.java - TV block's right-click GUI
  client/gui/GuiTabletPlayer.java - tablet's fullscreen GUI
```

## Building

Drop this into a repo and push — your existing GitHub Actions flow works the same way it does for
Golden Launcher: the workflow in `.github/workflows/build.yml` grabs JDK 8 + Gradle and runs a build,
uploading the jar as an artifact.

Since this environment has no network access, **I couldn't actually compile this before handing it
off** — the Forge/MCP method signatures are correct to the best of my knowledge for 1.12.2, but there's
a real chance CI throws a couple of small errors (a renamed field, a slightly different overload, etc).
Given you're already used to debugging builds through GitHub Actions logs, that's the fastest way to
iron out anything version-specific — push it, read the first error, fix, repeat.

## Known limitations / good next steps

- No looping — video just stops on the last frame when it ends. Easy fix: add `-stream_loop -1` to
  the ffmpeg args in `VideoPlayer.java` if you want looping TVs.
- Audio/video sync is "close enough," not frame-accurate (two separate ffmpeg processes, started
  together). Fine for a TV-in-a-room vibe, not fine for lip-sync-critical content.
- Tablet doesn't persist the last video path across relogs (kept in memory only) — could be added
  with a small item NBT + packet round trip.
- No YouTube/URL streaming — only local files. ffmpeg *can* take a URL instead of a file path if you
  ever want to extend `VideoPlayer` to accept one directly.
