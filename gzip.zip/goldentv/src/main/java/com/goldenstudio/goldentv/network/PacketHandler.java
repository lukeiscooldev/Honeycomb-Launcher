package com.goldenstudio.goldentv.network;

import com.goldenstudio.goldentv.GoldenTV;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class PacketHandler {

    public static SimpleNetworkWrapper NETWORK;
    private static int packetId = 0;

    public static void registerMessages() {
        NETWORK = NetworkRegistry.INSTANCE.newSimpleChannel(GoldenTV.MODID);
        NETWORK.registerMessage(MessagePlayVideo.Handler.class, MessagePlayVideo.class, packetId++, Side.SERVER);
    }
}
