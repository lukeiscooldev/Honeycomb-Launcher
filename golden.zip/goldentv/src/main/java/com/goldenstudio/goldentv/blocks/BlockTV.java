package com.goldenstudio.goldentv.blocks;

import com.goldenstudio.goldentv.GoldenTV;
import com.goldenstudio.goldentv.tileentity.TileEntityTV;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.creativetab.CreativeTabs;

public class BlockTV extends Block implements ITileEntityProvider {

    public BlockTV() {
        super(Material.IRON);
        setRegistryName("goldentv_tv");
        setUnlocalizedName("goldentv_tv");
        setHardness(2.0F);
        setResistance(10.0F);
        setCreativeTab(CreativeTabs.DECORATIONS);
    }

    @Override
    public TileEntity createNewTileEntity(World worldIn, int meta) {
        return new TileEntityTV();
    }

    @Override
    public void onBlockPlacedBy(World worldIn, BlockPos pos, net.minecraft.block.state.IBlockState state,
                                 EntityLivingBase placer, ItemStack stack) {
        super.onBlockPlacedBy(worldIn, pos, state, placer, stack);
        TileEntity te = worldIn.getTileEntity(pos);
        if (te instanceof TileEntityTV) {
            // face the player who placed it, so the screen looks outward at them
            EnumFacing facing = placer.getHorizontalFacing().getOpposite();
            ((TileEntityTV) te).setFacing(facing);
        }
    }

    @Override
    public boolean onBlockActivated(World worldIn, BlockPos pos, net.minecraft.block.state.IBlockState state,
                                     EntityPlayer playerIn, EnumHand hand, EnumFacing facing,
                                     float hitX, float hitY, float hitZ) {
        if (worldIn.isRemote) {
            GoldenTV.proxy.openVideoConfigGui(pos);
        }
        return true;
    }

    @Override
    public void breakBlock(World worldIn, BlockPos pos, net.minecraft.block.state.IBlockState state) {
        super.breakBlock(worldIn, pos, state);
        worldIn.removeTileEntity(pos);
    }

    @Override
    public boolean isOpaqueCube(net.minecraft.block.state.IBlockState state) {
        return true;
    }

    @Override
    public boolean isFullCube(net.minecraft.block.state.IBlockState state) {
        return true;
    }
}
