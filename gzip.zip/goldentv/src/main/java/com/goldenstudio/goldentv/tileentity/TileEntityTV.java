package com.goldenstudio.goldentv.tileentity;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;

import javax.annotation.Nullable;

public class TileEntityTV extends TileEntity implements ITickable {

    private String videoPath = "";
    private boolean playing = false;
    // world total-time (ticks) at which playback started - lets each client
    // (including late joiners) figure out how far into the video to seek so
    // everyone watching stays roughly in sync with each other.
    private long startWorldTime = 0L;

    // NOTE: facing is NOT stored here anymore - it lives on the block's
    // FACING blockstate property (see BlockTV). The renderer reads it from
    // world.getBlockState(pos) instead of from this TE.

    @Override
    public void update() {
        // nothing needed server-side each tick; playback is entirely client-driven
    }

    public String getVideoPath() {
        return videoPath;
    }

    public boolean isPlaying() {
        return playing;
    }

    public long getStartWorldTime() {
        return startWorldTime;
    }

    /** Called server-side only. Pushes an update packet out to every client tracking this chunk. */
    public void startPlayback(String path) {
        this.videoPath = path;
        this.playing = true;
        this.startWorldTime = world.getTotalWorldTime();
        markDirty();
        pushToClients();
    }

    /** Called server-side only. */
    public void stopPlayback() {
        this.playing = false;
        markDirty();
        pushToClients();
    }

    private void pushToClients() {
        if (world != null && !world.isRemote) {
            net.minecraft.block.state.IBlockState state = world.getBlockState(pos);
            world.notifyBlockUpdate(pos, state, state, 3);
        }
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        compound.setString("videoPath", videoPath);
        compound.setBoolean("playing", playing);
        compound.setLong("startWorldTime", startWorldTime);
        return compound;
    }

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        videoPath = compound.getString("videoPath");
        playing = compound.getBoolean("playing");
        startWorldTime = compound.getLong("startWorldTime");
    }

    @Override
    public NBTTagCompound getUpdateTag() {
        return writeToNBT(new NBTTagCompound());
    }

    @Override
    public void handleUpdateTag(NBTTagCompound tag) {
        readFromNBT(tag);
    }

    @Nullable
    @Override
    public SPacketUpdateTileEntity getUpdatePacket() {
        return new SPacketUpdateTileEntity(getPos(), 1, getUpdateTag());
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        readFromNBT(pkt.getNbtCompound());
    }
}
