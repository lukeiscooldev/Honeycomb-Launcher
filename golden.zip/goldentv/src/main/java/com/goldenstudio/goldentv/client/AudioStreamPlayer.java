package com.goldenstudio.goldentv.client;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import java.io.File;
import java.io.InputStream;

/**
 * Plays the audio track of the video via ffmpeg -> raw PCM -> javax.sound.
 * This is a best-effort sync with the video frames (both are started at
 * roughly the same time); it is NOT sample-accurate lip sync. Good enough
 * for a TV-in-a-room use case.
 */
@SideOnly(Side.CLIENT)
public class AudioStreamPlayer {

    private static final int SAMPLE_RATE = 44100;
    private static final int CHANNELS = 2;

    private final File videoFile;
    private final double startOffsetSeconds;
    private Process ffmpegProcess;
    private Thread audioThread;
    private volatile boolean running = false;

    public AudioStreamPlayer(File videoFile, double startOffsetSeconds) {
        this.videoFile = videoFile;
        this.startOffsetSeconds = startOffsetSeconds;
    }

    public void start() {
        running = true;
        audioThread = new Thread(this::run, "goldentv-audio");
        audioThread.setDaemon(true);
        audioThread.start();
    }

    private void run() {
        try {
            ProcessBuilder pb = new ProcessBuilder(
                    "ffmpeg",
                    "-ss", String.valueOf(startOffsetSeconds),
                    "-i", videoFile.getAbsolutePath(),
                    "-f", "s16le",
                    "-ar", String.valueOf(SAMPLE_RATE),
                    "-ac", String.valueOf(CHANNELS),
                    "-vn",
                    "-loglevel", "error",
                    "pipe:1"
            );
            ffmpegProcess = pb.start();
            InputStream in = ffmpegProcess.getInputStream();

            AudioFormat format = new AudioFormat(SAMPLE_RATE, 16, CHANNELS, true, false);
            SourceDataLine line = AudioSystem.getSourceDataLine(format);
            line.open(format);
            line.start();

            byte[] buf = new byte[4096];
            int read;
            while (running && (read = in.read(buf)) != -1) {
                line.write(buf, 0, read);
            }
            line.drain();
            line.close();
        } catch (Exception e) {
            // audio is a nice-to-have; silently fall back to video-only if it fails
        }
    }

    public void stop() {
        running = false;
        if (ffmpegProcess != null) {
            ffmpegProcess.destroy();
        }
        if (audioThread != null) {
            audioThread.interrupt();
        }
    }
}
