package com.goldenstudio.goldentv.proxy;

import com.goldenstudio.goldentv.client.gui.GuiTabletPlayer;
import com.goldenstudio.goldentv.client.gui.GuiVideoConfig;
import com.goldenstudio.goldentv.client.render.TileEntityTVRenderer;
import com.goldenstudio.goldentv.init.ModBlocks;
import com.goldenstudio.goldentv.tileentity.TileEntityTV;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ItemModelMesher;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.registry.ClientRegistry;
import net.minecraftforge.common.MinecraftForge;

public class ClientProxy extends CommonProxy {

    @Override
    public void init() {
        super.init();
        registerRenderers();
        MinecraftForge.EVENT_BUS.register(new com.goldenstudio.goldentv.client.ClientEventHandler());
    }

    private void registerRenderers() {
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityTV.class, new TileEntityTVRenderer());

        registerItemModel(Item.getItemFromBlock(ModBlocks.TV), 0, "goldentv_tv");
        registerItemModel(com.goldenstudio.goldentv.init.ModItems.TABLET, 0, "goldentv_tablet");
    }

    private void registerItemModel(Item item, int meta, String name) {
        ItemModelMesher mesher = Minecraft.getMinecraft().getRenderItem().getItemModelMesher();
        mesher.register(item, meta, new ModelResourceLocation("goldentv:" + name, "inventory"));
    }

    @Override
    public void openVideoConfigGui(BlockPos pos) {
        Minecraft.getMinecraft().displayGuiScreen(new GuiVideoConfig(pos));
    }

    @Override
    public void openTabletGui() {
        Minecraft.getMinecraft().displayGuiScreen(new GuiTabletPlayer());
    }
}
