package com.goldenstudio.goldentv.tileentity;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;

import javax.annotation.Nullable;

public class TileEntityTV extends TileEntity implements ITickable {

    private String videoPath = "";
    private boolean playing = false;
    // world total-time (ticks) at which playback started - lets the client
    // figure out how far into the video it should seek when it starts decoding,
    // so late joiners / re-renders stay roughly in sync with everyone else.
    private long startWorldTime = 0L;
    private int facingIndex = EnumFacing.NORTH.getHorizontalIndex();

    @Override
    public void update() {
        // nothing needed server-side each tick; playback is entirely client-driven
    }

    public String getVideoPath() {
        return videoPath;
    }

    public boolean isPlaying() {
        return playing;
    }

    public long getStartWorldTime() {
        return startWorldTime;
    }

    public EnumFacing getFacing() {
        return EnumFacing.getHorizontal(facingIndex);
    }

    public void setFacing(EnumFacing facing) {
        this.facingIndex = facing.getHorizontalIndex();
        markDirty();
    }

    /** Called server-side only. Pushes an update packet out to watching clients. */
    public void startPlayback(String path) {
        this.videoPath = path;
        this.playing = true;
        this.startWorldTime = world.getTotalWorldTime();
        markDirty();
        pushToClients();
    }

    /** Called server-side only. */
    public void stopPlayback() {
        this.playing = false;
        markDirty();
        pushToClients();
    }

    private void pushToClients() {
        if (world != null && !world.isRemote) {
            net.minecraft.block.state.IBlockState state = world.getBlockState(pos);
            world.notifyBlockUpdate(pos, state, state, 3);
        }
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        compound.setString("videoPath", videoPath);
        compound.setBoolean("playing", playing);
        compound.setLong("startWorldTime", startWorldTime);
        compound.setInteger("facing", facingIndex);
        return compound;
    }

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        videoPath = compound.getString("videoPath");
        playing = compound.getBoolean("playing");
        startWorldTime = compound.getLong("startWorldTime");
        facingIndex = compound.hasKey("facing") ? compound.getInteger("facing") : EnumFacing.NORTH.getHorizontalIndex();
    }

    @Override
    public NBTTagCompound getUpdateTag() {
        return writeToNBT(new NBTTagCompound());
    }

    @Override
    public void handleUpdateTag(NBTTagCompound tag) {
        readFromNBT(tag);
    }

    @Nullable
    @Override
    public SPacketUpdateTileEntity getUpdatePacket() {
        return new SPacketUpdateTileEntity(getPos(), 1, getUpdateTag());
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        readFromNBT(pkt.getNbtCompound());
    }
}
